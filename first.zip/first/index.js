const express=require('express')
const app=express();
let http = require('http');
const fs=require('fs');
const cors=require('cors');
const bodyparser=require('body-parser');

app.use(bodyparser.json());
app.use(bodyparser.urlencoded({ extended: false }));
let employees=[
{
id:1,
name:'Kiran',
email:'k@gmail.com',
team_ID:'A',
role_ID:'1'
}]

app.get('/',(req,res) =>{
res.sendFile(__dirname+"/home.html");
});


app.get('/employees',(req,res) =>{
res.send(employees)
});



app.get('/employees/:id',(req,res) =>{

const emid=parseInt(req.params.id);
console.log(emid)
for(let eid of employees){
console.log('for'+eid.id)
if(parseInt(eid.id)===emid){
console.log(eid.id)
res.json(eid);
console.log('Inside If '+eid.name)

return;}
}
res.status(404).send('Employee not Found');
});


app.post('/employ', (req, res) => {
    let emp = req.body;
    console.log(emp)

    // Output the book to the console for debugging

    employees.push(emp);

    res.send('Employee Added');
    });

//app.post('/employees',(req,res)=>{
//const emp={
//id:employees.length+1,
//});
//let handleRequest = (request, response) => {
//    response.writeHead(200, {
//        'Content-Type': 'text/html'
//    });
//    fs.readFile('./index.html', null, function (error, data) {
//        if (error) {
//            res.writeHead(404);
//            res.write('Whoops! File not found!');
//        } else {
//            response.write(data);
//        }
//        res.end();
//    });
//};

//http.createServer(handleRequest).listen(8000);
const port=3000;
app.listen(port,() =>console.log('listening'));